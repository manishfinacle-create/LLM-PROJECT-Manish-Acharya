# ⚡ MultiMind — Multi-LLM Side-by-Side Chat App

> Ask once. Compare three AI answers. Continue with the best one.

---

## 📋 Table of Contents

1. [Project Overview](#1-project-overview)
2. [What You Will Build](#2-what-you-will-build)
3. [Project Structure](#3-project-structure)
4. [Prerequisites Explained](#4-prerequisites-explained)
5. [Setup Guide (Step by Step)](#5-setup-guide-step-by-step)
6. [Getting API Keys](#6-getting-api-keys)
7. [Running the App](#7-running-the-app)
8. [How the Code Works](#8-how-the-code-works)
9. [Source Code Reference](#9-source-code-reference)
10. [Common Errors & Fixes](#10-common-errors--fixes)
11. [Extending the Project](#11-extending-the-project)
12. [Learning Checkpoint](#12-learning-checkpoint)

---

## 1. Project Overview

**MultiMind** is a full-stack web application that sends the same user question to **three AI models simultaneously** — OpenAI GPT-4o, Anthropic Claude, and Google Gemini — and displays all answers in a **side-by-side panel**.

The user can then click **"Continue with this model"** to pick one AI and carry on a multi-turn conversation. Each model maintains its own independent chat history.

### Tech Stack

| Layer | Technology |
|-------|-----------|
| Backend | Python 3.10+, Flask |
| LLM APIs | OpenAI, Anthropic, Google Gemini |
| Parallelism | `concurrent.futures.ThreadPoolExecutor` |
| Frontend | Vanilla HTML, CSS, JavaScript |
| Config | `python-dotenv` (.env file) |

---

## 2. What You Will Build

```
┌──────────────────────────────────────────────────────────────┐
│  Phase 1: Side-by-Side Comparison                            │
│                                                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐       │
│  │   GPT-4o     │  │ Claude 3.5   │  │ Gemini 1.5   │       │
│  │─────────────│  │─────────────│  │─────────────│       │
│  │ Answer A...  │  │ Answer B...  │  │ Answer C...  │       │
│  │              │  │              │  │              │       │
│  │ [Continue →] │  │ [Continue →] │  │ [Continue →] │       │
│  └──────────────┘  └──────────────┘  └──────────────┘       │
└──────────────────────────────────────────────────────────────┘
        ↓ User clicks "Continue with Claude 3.5"
┌──────────────────────────────────────────────────────────────┐
│  Phase 2: Single-Model Chat (Claude selected)                │
│                                                              │
│  You:      What is recursion?                                │
│  Claude:   Recursion is when a function calls itself...      │
│  You:      Can you give me a Python example?                 │
│  Claude:   Sure! Here's a factorial example...               │
│                                                              │
│  [← Compare again]                                           │
└──────────────────────────────────────────────────────────────┘
```

---

## 3. Project Structure

```
multi-llm-chat/
│
├── app/
│   ├── __init__.py          # Makes 'app' a Python package
│   ├── main.py              # Flask routes (the web server)
│   └── llm_clients.py       # All LLM API calls live here
│
├── templates/
│   └── index.html           # The single HTML page
│
├── static/
│   ├── css/
│   │   └── style.css        # All visual styling
│   └── js/
│       └── app.js           # Frontend logic (fetch, render, chat)
│
├── docs/
│   └── README.md            # This file
│
├── .env.example             # Template — copy to .env and fill keys
├── .env                     # Your actual secrets (NOT in git)
├── .gitignore               # Tells git to ignore .env, __pycache__, etc.
└── requirements.txt         # Python dependencies
```

### Why This Structure?

- `app/` separates backend logic from templates and static files
- `llm_clients.py` is isolated so you can add/remove LLMs in one place
- `static/` and `templates/` are Flask conventions — the framework knows where to look
- `.env` keeps secrets out of your code

---

## 4. Prerequisites Explained

### Python Concepts You Need

#### Variables, Functions, Dicts

```python
# A dict maps keys to values — used for message history
message = {"role": "user", "content": "What is Python?"}

# A list of dicts — the conversation history
history = [
    {"role": "user",      "content": "Hello"},
    {"role": "assistant", "content": "Hi! How can I help?"},
]

# A function that takes history and returns a string
def call_openai(history: list, user_message: str) -> str:
    # ... API call ...
    return "The answer is..."
```

#### What is a "system prompt"?

```python
# A SYSTEM prompt sets the AI's behavior/personality.
# It is NOT part of the conversation — it's like backstage instructions.
SYSTEM_PROMPT = "You are a helpful, concise assistant."

# A USER prompt is what the user actually says.
user_message = "Explain recursion."

# Together they form the messages array sent to the API:
messages = [
    {"role": "system", "content": SYSTEM_PROMPT},   # ← system
    {"role": "user",   "content": user_message},     # ← user prompt
]
```

#### What is an API key?

An API key is a **password** that identifies you to an external service.

```
OPENAI_API_KEY=sk-proj-abc123...
               ↑
               This is YOUR credential. Keep it private.
               Anyone with this key can charge your account.
```

**Never:**
- Print it to the console
- Put it in your code directly (hardcode)
- Push it to GitHub

**Always:**
- Store it in `.env`
- Load it with `os.environ.get("OPENAI_API_KEY")`
- Add `.env` to `.gitignore`

#### Virtual Environment

A virtualenv is an isolated Python installation for your project. It prevents package version conflicts between projects.

```bash
python -m venv venv         # Creates a folder called 'venv'
source venv/bin/activate    # macOS/Linux
venv\Scripts\activate       # Windows PowerShell

# Now pip installs go INTO venv, not your system Python
pip install -r requirements.txt
```

---

## 5. Setup Guide (Step by Step)

### Step 1 — Clone or Download the Project

```bash
# If using git:
git clone https://github.com/yourname/multi-llm-chat.git
cd multi-llm-chat

# Or just download and unzip, then open a terminal in that folder
```

### Step 2 — Create a Virtual Environment

```bash
# Create the environment
python -m venv venv

# Activate it
# macOS / Linux:
source venv/bin/activate

# Windows CMD:
venv\Scripts\activate.bat

# Windows PowerShell:
venv\Scripts\Activate.ps1
```

You should see `(venv)` in your terminal prompt. That means it's active.

### Step 3 — Install Dependencies

```bash
pip install -r requirements.txt
```

This installs:
- `flask` — the web framework
- `python-dotenv` — loads `.env` file
- `openai` — OpenAI Python SDK
- `anthropic` — Anthropic Claude SDK
- `google-generativeai` — Google Gemini SDK

### Step 4 — Set Up Your API Keys

```bash
# Copy the example file
cp .env.example .env

# Open .env in VS Code
code .env
```

Then fill in your keys (see Section 6 for where to get them):

```
OPENAI_API_KEY=sk-...
ANTHROPIC_API_KEY=sk-ant-...
GOOGLE_API_KEY=AI...
FLASK_SECRET_KEY=pick-any-random-string
```

> ⚠️ **You don't need all three keys to run the app.** If a key is missing, that model will return a helpful warning message instead of crashing the app.

### Step 5 — Verify Setup

```bash
python -c "import flask, openai, anthropic, google.generativeai; print('All packages OK!')"
```

You should see: `All packages OK!`

---

## 6. Getting API Keys

### OpenAI (GPT-4o)

1. Go to [platform.openai.com/api-keys](https://platform.openai.com/api-keys)
2. Sign in or create an account
3. Click **"Create new secret key"**
4. Copy the key (you can only see it once!)
5. Note: GPT-4o requires a paid account or free trial credits

### Anthropic (Claude)

1. Go to [console.anthropic.com/settings/keys](https://console.anthropic.com/settings/keys)
2. Sign in or create an account
3. Click **"Create Key"**
4. Copy the key
5. Note: New accounts get free API credits

### Google Gemini

1. Go to [aistudio.google.com/app/apikey](https://aistudio.google.com/app/apikey)
2. Sign in with your Google account
3. Click **"Create API key"**
4. Copy the key
5. Note: Gemini 1.5 Flash has a free tier

---

## 7. Running the App

```bash
# Make sure your venv is activated (you see "(venv)" in the prompt)
cd multi-llm-chat

# Run the Flask development server
python app/main.py
```

You should see:

```
 * Running on http://127.0.0.1:5000
 * Debug mode: on
```

Open your browser and go to: **http://localhost:5000**

### Stopping the Server

Press `Ctrl + C` in the terminal.

---

## 8. How the Code Works

### Request Flow: Phase 1 (Compare All)

```
Browser                         Flask Server                    LLM APIs
  │                                   │                            │
  │  POST /api/ask-all                │                            │
  │  { "message": "What is AI?" } ──►│                            │
  │                                   │── Thread 1: call_openai() ─►│ OpenAI
  │                                   │── Thread 2: call_claude()  ─►│ Anthropic
  │                                   │── Thread 3: call_gemini()  ─►│ Google
  │                                   │                            │
  │                                   │◄── All 3 results ──────────│
  │◄── JSON: { results: {...} } ──────│                            │
  │                                   │                            │
  │  Render 3 answer cards            │                            │
```

The key technique here is **parallel execution** using Python's `concurrent.futures`:

```python
# llm_clients.py — simplified explanation
def query_all_models(user_message):
    results = {}

    # ThreadPoolExecutor runs all 3 API calls at the SAME TIME
    # Instead of: call OpenAI (3s) → call Claude (3s) → call Gemini (3s) = 9s
    # We get:     all three simultaneously = ~3s
    with ThreadPoolExecutor(max_workers=3) as executor:
        futures = {
            executor.submit(call_openai, [], user_message): "openai",
            executor.submit(call_claude, [], user_message): "claude",
            executor.submit(call_gemini, [], user_message): "gemini",
        }
        for future in as_completed(futures):
            model_key, answer = future.result()
            results[model_key] = answer

    return results
```

### Request Flow: Phase 2 (Single Model Chat)

```
Browser                         Flask Server                Claude API
  │                                   │                         │
  │  POST /api/continue               │                         │
  │  {                                │                         │
  │    model: "claude",               │                         │
  │    history: [                     │                         │
  │      {role:"user", content:"..."},│                         │
  │      {role:"assistant", content}  │                         │
  │    ],                             │                         │
  │    message: "Tell me more"        │                         │
  │  }                           ────►│                         │
  │                                   │── call_claude(history) ─►│
  │                                   │◄── response ────────────│
  │◄── { response: "..." } ───────────│                         │
```

Each model call includes the **full conversation history**, which is how the AI "remembers" what was said earlier. The LLM APIs are stateless — you always re-send the entire conversation.

### Frontend State Machine

```
            ┌─────────────┐
  start ──► │   compare   │ ◄────────────────────────────┐
            └─────────────┘                              │
                   │                                     │
          user types + sends                     clicks "← Compare again"
                   │                                     │
            ┌─────────────┐                      ┌──────────────┐
            │  loading    │                      │              │
            │  (3 spinners│                      │   chat       │
            │   spinning) │                      │   phase      │
            └─────────────┘                      └──────────────┘
                   │                                     ▲
            answers arrive                               │
                   │                          user clicks "Continue →"
            ┌─────────────┐                             │
            │ answer grid │ ──────────────────────────► │
            │ (3 cards)   │
            └─────────────┘
```

---

## 9. Source Code Reference

### `app/main.py` — Flask Routes

```python
@app.route("/api/ask-all", methods=["POST"])
def ask_all_models():
    """Receives a message, returns all 3 model answers."""
    data = request.get_json()          # Parse JSON body
    user_message = data.get("message") # Extract the message
    results = query_all_models(user_message)  # Call all 3 LLMs
    return jsonify({"results": results})      # Return JSON
```

**What `request.get_json()` does:** Flask parses the JSON body of the POST request into a Python dictionary automatically.

**What `jsonify()` does:** Converts a Python dict to a proper HTTP JSON response with correct headers.

---

```python
@app.route("/api/continue", methods=["POST"])
def continue_with_model():
    """Receives model + history + new message, returns one model's reply."""
    data = request.get_json()
    model_key  = data.get("model")    # e.g. "claude"
    history    = data.get("history")  # Full chat history
    user_message = data.get("message")
    response = query_single_model(model_key, history, user_message)
    return jsonify({"response": response})
```

---

### `app/llm_clients.py` — Model Config

```python
# This dict controls what appears in the UI.
# To add a new model: add an entry here + a call_xxx() function + add to MODEL_CALLERS.
AVAILABLE_MODELS = {
    "openai": {
        "label": "GPT-4o",
        "color": "#10A37F",
        "icon": "🟢",
    },
    "claude": { ... },
    "gemini": { ... },
}
```

---

### `static/js/app.js` — Key Frontend Functions

```javascript
// Called when user presses Enter or clicks send
function handleSend() {
    const msg = userInput.value.trim();
    if (state.phase === "compare") {
        askAllModels(msg);    // Phase 1: ask all
    } else {
        continueChat(msg);    // Phase 2: ask one
    }
}

// Fetch all answers in parallel (the server handles parallelism)
async function askAllModels(message) {
    const res = await fetch("/api/ask-all", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message }),
    });
    const data = await res.json();
    renderAnswerGrid(data.results, message);
}
```

**Why `async/await`?** Network requests take time. `async/await` lets the browser stay responsive while waiting for the server to respond — without blocking the UI.

---

## 10. Common Errors & Fixes

### `ModuleNotFoundError: No module named 'flask'`

**Cause:** Virtual environment not activated, or packages not installed.

```bash
# Activate venv first
source venv/bin/activate  # macOS/Linux
venv\Scripts\activate     # Windows

# Then install
pip install -r requirements.txt
```

---

### `⚠️ OPENAI_API_KEY not set in .env file`

**Cause:** You haven't created `.env`, or the key name is wrong.

```bash
# Check your .env file exists and has the right key name
cat .env

# Should contain exactly:
OPENAI_API_KEY=sk-...
```

---

### `❌ OpenAI Error: 401 Unauthorized`

**Cause:** Wrong or expired API key.

Fix: Go back to the API provider, generate a new key, update `.env`.

---

### `❌ OpenAI Error: 429 Too Many Requests`

**Cause:** You've hit the rate limit or your free tier is exhausted.

Fix: Wait a minute, or add billing to your account.

---

### `Address already in use` (port 5000)

**Cause:** Another process is using port 5000.

```bash
# Kill the process on port 5000
# macOS/Linux:
lsof -ti:5000 | xargs kill -9

# Or run Flask on a different port:
python app/main.py --port 5001
```

---

### `FileNotFoundError: templates/index.html`

**Cause:** Running Flask from the wrong directory.

```bash
# Always run from the project root (where requirements.txt is)
cd multi-llm-chat
python app/main.py
```

---

### CORS or fetch error in browser

**Cause:** JavaScript is running on a different origin than Flask.

Fix: Always open `http://localhost:5000` in your browser — do NOT open `index.html` directly as a file.

---

## 11. Extending the Project

### Add a New LLM (e.g. Mistral)

1. **Add to `AVAILABLE_MODELS`** in `llm_clients.py`:
```python
"mistral": {
    "label": "Mistral 7B",
    "color": "#FF7000",
    "icon": "🟡",
}
```

2. **Write the caller function**:
```python
def call_mistral(history, user_message):
    # Use the mistralai Python package
    from mistralai.client import MistralClient
    client = MistralClient(api_key=os.environ.get("MISTRAL_API_KEY"))
    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    messages.extend(history)
    messages.append({"role": "user", "content": user_message})
    response = client.chat(model="mistral-tiny", messages=messages)
    return response.choices[0].message.content
```

3. **Register it**:
```python
MODEL_CALLERS = {
    "openai":  call_openai,
    "claude":  call_claude,
    "gemini":  call_gemini,
    "mistral": call_mistral,   # ← add this
}
```

4. Add `MISTRAL_API_KEY=...` to your `.env`.

That's it! The UI will automatically add a 4th column.

---

### Add Markdown Rendering

Replace the plain text answer with rendered Markdown using the `marked` library:

In `index.html`, add to `<head>`:
```html
<script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>
```

In `app.js`, change:
```javascript
contentEl.textContent = content;
// to:
contentEl.innerHTML = marked.parse(content);
```

---

### Save Chat History to a File

In `main.py`, add an endpoint:
```python
import json
from datetime import datetime

@app.route("/api/save-chat", methods=["POST"])
def save_chat():
    data = request.get_json()
    filename = f"chat_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    with open(f"saved_chats/{filename}", "w") as f:
        json.dump(data, f, indent=2)
    return jsonify({"saved": filename})
```

---

## 12. Learning Checkpoint

After completing this project, you should be able to answer:

**Python:**
- [ ] What does `ThreadPoolExecutor` do, and why is it faster than sequential calls?
- [ ] What is the difference between `os.environ.get()` and hardcoding a value?
- [ ] Why do we use a list of dicts for conversation history?

**Web:**
- [ ] What is the difference between a GET and POST request?
- [ ] What does `async/await` solve in JavaScript?
- [ ] What is `jsonify()` doing in Flask?

**LLM Concepts:**
- [ ] What is the purpose of a system prompt?
- [ ] Why must you re-send the entire conversation history on every API call?
- [ ] What does a 429 error mean from an API?

**Security:**
- [ ] Why is your `.env` file in `.gitignore`?
- [ ] What would happen if you pushed your API keys to GitHub?

---

## Quick Reference Card

```bash
# First time setup
python -m venv venv
source venv/bin/activate  # or venv\Scripts\activate on Windows
pip install -r requirements.txt
cp .env.example .env
# Edit .env with your keys

# Every time you work on the project
source venv/bin/activate
python app/main.py
# Open http://localhost:5000
```

---

*Built with Flask · OpenAI · Anthropic · Google Gemini*
